import warnings

from quimb.schematic import *

warnings.warn(
    "The 'quimb.experimental.schematic' has been moved to `quimb.schematic`.",
)
