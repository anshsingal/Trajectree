"""Linear algebra routines to solve quantum systems for example.
"""

from ..utils import find_library

SLEPC4PY_FOUND = find_library("slepc4py")
