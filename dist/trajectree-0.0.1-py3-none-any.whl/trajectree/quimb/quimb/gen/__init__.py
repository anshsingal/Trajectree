"""Functions for generating quantum objects.
"""
