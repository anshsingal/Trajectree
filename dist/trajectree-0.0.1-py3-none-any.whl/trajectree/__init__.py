import sys
import os
sys.path.append(os.path.abspath(__file__).replace('__init__.py', 'quimb'))